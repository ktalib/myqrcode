<?php
    // call sidenav
    require_once('sidenav.php');
    include_once('include/database.php');
    include('com/includes/config.php');
   
    $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    $pageID = explode('?', $actual_link);
    $pageActID = end($pageID);

    // getting actual Id data



 

    $sql = "SELECT * FROM users WHERE id='$pageActID'";
    $result = mysqli_query($db, $sql);
    $resultCheck = mysqli_num_rows($result);
    $row = mysqli_fetch_array($result);

    $row['id'];
      
    $row['fullname'];
    $row['username'];
     $row['age'];
    $row['email'];
    $row['password'];
    $row['userImage'];
    $row['status'];

    $row['join_date'];
    $row['sex'];
    $row['beneficiary_id'];
    $row['household_size'];
    $row['pre_capita'];
    $row['community'];
    $row['phone'];
    $row['image'];

   
  
     
        
        
        
            
            

    $status =  $_SESSION['id'];
 
?>

 
 
     
  <?php  echo "
        <div class='jumbotron'> ;"?>
                       <?php echo " <div class='col-sm-12'>"; ?>
             <?php echo "<div class='oldInfo'>"; ?>
             <a href="com/edit-student.php?stid=<?php echo $row["id"];?>">
 <?php echo "<button type='button' class='btn btn-danger'>". $row['status']." </button>"; ?>
</a>
                 <?php echo " <table>"; ?>
                       <?php echo " <thead>
                            <th><h3>Beneficiary</h3></th>
                        </thead>";?>
           
                          <?php echo "  <tr>
                                <td colspan='3'>
                                    <img src='img/usersimages/".$row['id']."' class='rounded' alt='".$row['fullname']."' width='100px' height='100px'>
                                </td>
                            </tr>"; ?>
                           
             <?php echo  "<tbody>"; ?>

 <?php echo " 
 <div class='alert alert-success'>
  <strong> Date Registered:</strong> ".$row['join_date']." 
</div>


 "; ?>
                           <?php echo " <tr>
                                <td class='lead' colspan='2'> First Name : </td>
                                <td class='lead'>".$row['fullname']." </td>
                            </tr>"; ?>


                           <?php echo " <tr>
                                <td class='lead' colspan='2'> Last Name : </td>
                                <td class='lead'>".$row['username']." </td>
                            </tr>"; ?>


                           <?php echo "  <tr>
                            <td class='lead' colspan='2'> Age : </td>
                            <td class='lead'>".$row['age']." </td>
                             </tr>"; ?>


                        <!-- ffdgdfgdf
 -->

                             <?php echo "  <tr>
                            <td class='lead' colspan='2'> Sex : </td>
                            <td class='lead'>".$row['sex']." </td>
                             </tr>"; ?>

                                <?php echo "  <tr>
                            <td class='lead' colspan='2'> Beneficiary ID : </td>
                            <td class='lead'>".$row['beneficiary_id']." </td>
                             </tr>"; ?>

                                <?php echo "  <tr>
                            <td class='lead' colspan='2'> Household Size : </td>
                            <td class='lead'>".$row['household_size']." </td>
                             </tr>"; ?>

                          

                                <?php echo "  <tr>
                            <td class='lead' colspan='2'> Pre Capita : </td>
                            <td class='lead'>".$row['pre_capita']." </td>
                             </tr>"; ?>

                                <?php echo "  <tr>
                            <td class='lead' colspan='2'> Community : </td>
                            <td class='lead'>".$row['community']." </td>
                             </tr>"; ?>

                             
                           

                           <?php echo " <tr>
                                <td class='lead' colspan='2'> Phone : </td>
                                <td class='lead'>". $row['email']." </td>
                            </tr> 

                           

                           
                        </tbody>
                    </table>; "?>

                     <?php echo "      
                                    <img src='QR_code.php?url=".$actual_link."   alt='".$row['fullname']."' width='200px' height='200px'>"; ?>

                                     <?php echo "
                </div>
            </div>
        </div>"; ?>

 
                    
                                                      



 
  


       
  <?php 
   $sql = "SELECT users.status,  users.id  from users WHERE id='$pageActID";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
 
 
 
foreach($results as $result)
    ?>
    
       
  
    
    <!--    $sql = "SELECT * FROM users WHERE id='$pageActID'";
    $result = mysqli_query($db, $sql);
    $resultCheck = mysqli_num_rows($result);
    $row = mysqli_fetch_array($result);

    $row['id']; -->


 
 
                




    
<!--   -->
<script>
    function preview() {
        'use strict';
        if(this.files && this.files[0]) {
            let reader = new FileReader();
            reader.onload = function (data) {
                'use strict';
                let img_preview = document.getElementById("img_preview");
                img_preview.src = data.target.result;
                img_preview.style.display = "block";
                img_preview.style.width = "200px";
                img_preview.style.height = "200px";
            }
            reader.readAsDataURL(this.files[0]);
        }
    }
</script>
<?php require_once('include/footer.html'); ?>