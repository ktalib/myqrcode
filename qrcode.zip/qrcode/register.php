<?php
    require_once('include/head.php');
?>
<body>
    <div class="container">
        <div class="row">
            <img src="img/ieee_logo.jpg" alt="logo" height="200px" class="m-auto" title="logo">
        </div>
        <div class="row">
            <div class="col-md-16 col-sm-12">
                <div class="register">
                    <div class="signIn">
                    <h2 style="color:#0076A1;">Sign in</h2>
                    <form  method="POST" action="include/login.inc.php">
                        <!-- Form Data -->
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" name="email" class="form-control" id="email" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
                        </div>
                        <!-- Submit -->
                        <div class="form-group"><button type="submit" name="login" class="btn btn-primary btn-block">Login</button></div>
                    </form>
                </div>
            </div> 
                </div>
            </div>
             
        </div>
    </div>
<?php require_once('include/footer.html'); ?>