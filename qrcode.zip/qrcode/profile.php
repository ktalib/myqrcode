 <?php
// start session
session_start();
 
    // call sidenav
    
    include_once('include/database.php');
    include('com/includes/config.php');
   
    $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    $pageID = explode('?', $actual_link);
    $pageActID = end($pageID);

    // getting actual Id data



  
 
    $sql = "SELECT * FROM users WHERE id='$pageActID'";
    $result = mysqli_query($db, $sql);
    $resultCheck = mysqli_num_rows($result);
    $row = mysqli_fetch_array($result);

    $row['id'];
      
    $row['fullname'];
    $row['username'];
     $row['age'];
    $row['email'];
    $row['password'];
    $row['userImage'];
    $row['status'];

    $row['join_date'];
    $row['sex'];
    $row['beneficiary_id'];
    $row['household_size'];
    $row['pre_capita'];
    $row['community'];
    $row['phone'];
    $row['image'];         
    $status =  $_SESSION['id'];
 
?>

   <?php 
   $sql = "SELECT users.status,  users.id  from users WHERE id='$pageActID";
$query = $dbh->prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
 
 
 
foreach($results as $result)
    ?>
 




<!DOCTYPE html>
<html>
<title>profile</title>

<!-- Mirrored from www.w3schools.com/w3css/tryw3css_templates_cv.htm by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Jun 2020 00:55:04 GMT -->
<meta charset='UTF-8'>
 <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
<script type="text/javascript" src="include/gstatic/loader.js"></script>
<link rel='stylesheet' href='css/w3.css'>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style12.css">
  <link rel='stylesheet' href='assets/font-awesome/4.5.0/css/font-awesome.min.css' />
 <script src="js/bootstrap.min.css"></script>
 <script src="js/jquery.min.js"></script>
 <script src="js/main.js"></script>
    <!-- text fonts -->
    <link rel='stylesheet' href='assets/css/fonts.googleapis.com.css' />
   

<style> 


       
  
html,body,h1,h2,h3,h4,h5,h6 {font-family: 'Roboto', sans-serif}

  
 
 </style>
<body class='w3-light-grey'>
   <?php include 'nav.php'; ?>

 


    <div id="about_dialog_bg">
    <div id="about_dialog">
<p onclick="about_dialog_hide()" style="color:white;"><span id="close_dialog"></span></p>
        <h2 align="center"> Tutorials  Books sharing</h2>
<p>Designed and programmed by : Iorkua Daniel</p>
<img src="img/me.jpg" alt="me" width="250px" height="250px"  />
    <p>System Developer.</p>
    <p> Programming tutorials  books sharing
 which helps users to upload,download and manage notes of their particular programming  course.
     </p>
        <hr style="
width: 350px;
border: 1px solid rgba(255, 255, 255, 0.6);
border-radius: 100%;
">      
    <a href="http://www.facebook.com/iorkua.katordaniel/"><span></span> Facebook </a>
    <a href="https://iorkuadaniel.000webhostapp.com/"><span ></span> Website</a>
    </div></div>

<!-- Page Container -->
<div class='w3-content w3-margin-top'>

  <!-- The Grid -->
  <div class='w3-row-padding'>
  
    <!-- Left Column -->
    <div class='w3-third'>
    
      <div class='w3-white w3-text-grey w3-card-2'>
         
        <?php echo " <div>
          <img src='img/default.png' style='width:100%' alt='Avatar'>
          <div class='w3-display-bottomleft w3-container w3-text-black'>
           
          </div>"; ?>

        </div>
        <div class='w3-container'>

            <?php echo "
         <i class='fa fa-user fa-fw w3-margin-right w3-large w3-text-teal'>
     </i>
            
           <h>Full Name: ".$row['fullname']." ".$row['username']."  </h>

            <p><i class='fa fa-briefcase fa-fw w3-margin-right w3-large w3-text-teal'>
            
          </i>Age: ".$row['age']." </p>
          <p><i class='fa fa-user fa-fw w3-margin-right w3-large w3-text-teal'>
            
          </i>Sex: ".$row['sex']."</p>
          <p><i class='fa fa-key fa-fw w3-margin-right w3-large w3-text-teal'>
            
          </i>Beneficiary ID: ".$row['beneficiary_id']."</p>

          <p><i class='fa fa-users fa-fw w3-margin-right w3-large w3-text-teal'>
            
          </i>Household Size: ".$row['household_size']." </p>

          <p><i class='fa fa-money fa-fw w3-margin-right w3-large w3-text-teal'>
            
          </i>Pre Capita: ".$row['pre_capita']." </p>

          <p><i class='fa fa-circle fa-fw w3-margin-right w3-large w3-text-teal'>
            
          </i>Community: ".$row['community']."</p> 
           
          <p><i class='fa fa-calendar fa-fw w3-margin-right w3-large w3-text-teal'>
            
          </i>Date Registered:  ".$row['join_date']."</p>

          <p><i class='fa fa-phone fa-fw w3-margin-right w3-large w3-text-teal'>
            
          </i>Phone: ". $row['email']."</p>"; ?>
          <hr>
          <div class="alert alert-warning">
  <strong>Warning!</strong> Click The Button Below if  the Beneficiary is yet to Recieve Capital .
</div>
  <p></p>
           <a href="com/status.php?stid=<?php echo $row["id"];?>">
 <?php echo "<button type='button' class='btn btn-danger'>". $row['status']." </button>"; ?>
</a>

<hr>
           
          
          
           
         
           
          
          <br>
        </div>
      </div><br>

    <!-- End Left Column -->
    </div>

    <!-- Right Column -->
    <div class='w3-twothird'>
    
     

      <div class='w3-container w3-card w3-white'>
        <h2 class='w3-text-grey w3-padding-16'><i class='fa fa-barcode fa-fw w3-margin-right w3-xxlarge w3-text-teal'></i>Beneficiary Qr Code</h2>
         <div class='w3-display-container'>
           <?php echo " 
          <img src='QR_code.php?url=".$actual_link." style='width:300px' alt='Avatar'>
          "; 
           ?>
           

        </div>
        <div class='w3-container'>
        <?php echo "<h5 class='w3-opacity'><b>  ".$row['fullname']. "  ".$row['username']. "<b></h5>"; ?>
           
      <h6 class='w3-text-teal'><i class='fa fa-calendar fa-fw w3-margin-right'>
        
      </i>Date Registered:<?php echo "".$row['join_date'].""; ?></h6>
       <?php echo "<h5>Beneficiary ID: ".$row['beneficiary_id']."</h5>"; ?>
        <hr>
        </div>
         </div>
      </div>

    <!-- End Right Column -->
    </div>
    
  <!-- End Grid -->
  </div>
  
  <!-- End Page Container -->
</div>
<!-- 
<div id="footer">
    <p align="center">COPYRIGHT &copy; Covid 19 Tracking ,ALL RIGHTS RESERVED</p>
</div> -->

</body>

<!-- Mirrored from www.w3schools.com/w3css/tryw3css_templates_cv.htm by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Jun 2020 00:55:07 GMT -->
</html>