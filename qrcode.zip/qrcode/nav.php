<div id="navbar" style="background-color: #00365c;">
    <ul>
        <li id="home"><a href="home.php">HOME</a></li>
        <li onclick="about_dialog_show1()" id="about"  id="apps"><a href="#">Scan Qrcode</a></li>
        <li id="games"><a href="beneficiaries.php">Register</a></li>
        <li id="contact"><a href="users.php">All Beneficiaries</a></li>
        <li   id="about" ><a href="search.php">Search</a></li>
        <li onclick="about_dialog_show()" id="about" style="float:right;"><a href="#">About</a></li>
    </ul>
    </div>
<!--||||||||||||||||||||||||||||||||||||||||||||||||||Div Mobile NavBar|||||||||||||||||||||||||||||||||||||||||||||||||||||-->
    <div id="m_navbar" style="background-color: #00365c;">
<a href="home.php" ><span class="fa fa-home"></span></a> <!--home-->
<a href="#" onclick="about_dialog_show1()" id="about" ><span class="fa fa-qrcode"></span></a>  
<a href="beneficiaries.php" ><span class="fa fa-pencil-square"></span></a> <!--news-->
<a href="search.php" ><span class="fa fa-search"></span></a> 

<a href="all.php" ><span class="fa fa-bar-chart-o"></span></a>
<a href="#" onclick="about_dialog_show()" id="about"><span class="fa fa-info"></span></a> 

 
 
<!--about-->
    </div>

 


    <div id="about_dialog_bg">
    <div id="about_dialog">
<p onclick="about_dialog_hide()" style="color:white;"><span id="close_dialog"></span></p>
        <h2 align="center"> About the this App </h2>
<p> </p>
<img src="img/me.png" alt="logo" width="250px" height="250px"  />
     
    <p> This is about the app write up, hth hoppd
        doiurl giolyun  hfhoiupjjfb  gdhjdhj d

     </p>
        <hr style="
width: 350px;
border: 1px solid rgba(255, 255, 255, 0.6);
border-radius: 100%;
">      
    <a href="http://www.facebook.com/iorkua.katordaniel/"><span></span> Facebook </a>
    <a href="https://iorkuadaniel.000webhostapp.com/"><span ></span> Website</a>
    </div></div>



    <div id="about_dialog_bg1">
    <div id="about_dialog1">
<p onclick="about_dialog_hide1()" style="color:white;"><span id="close_dialog"></span></p>
        <h2 align="center"> AM STILL WORKING ON THE QRCODE SCANNER  </h2>
 
        <hr style="
width: 350px;
border: 1px solid rgba(255, 255, 255, 0.6);
border-radius: 100%;
">      
     
    </div></div>
</div>