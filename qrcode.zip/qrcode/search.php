<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

<link rel='stylesheet' href='css/w3.css'>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel='stylesheet' href='assets/font-awesome/4.5.0/css/font-awesome.min.css' />
 <script src="js/bootstrap.min.css"></script>
 <script src="js/jquery.min.js"></script>
    <!-- text fonts -->
    <link rel='stylesheet' href='assets/css/fonts.googleapis.com.css' />
  <link rel='stylesheet' href='css/2.css' />
     <script src="js/main.js"></script>
</head>
  <style>
 

.icon-bar {
  width: 100%;
  background-color: #555;
  overflow: auto;
}

.icon-bar a {
  float: left;
  width: 20%;
  text-align: center;
  padding: 12px 0;
  transition: all 0.3s ease;
  color: white;
  font-size: 36px;
}

.icon-bar a:hover {
  background-color: #000;
}

.active {
  background-color: #4CAF50;
}
</style>
</head>
<body style="background-color: #02292f;">

  <?php include 'nav.php'; ?>
<div id="header" align="center" style="padding-top: 100px;padding-bottom:100px;">

<div class="container">
   
   
         
<div class="form-group">
  <input type="text" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="Search for id.." autocomplete="off">
</div>
    
<hr style="color: red;">
   <div class="table-responsive">


  <table class="table table-dark table-hover" id="myTable">
      <thead>
      <tr>
        <th>Id</th>
        <th>Name</th>
        
        
        <th>Status</th>
        <th> View</th>
      </tr>
    </thead>  
     <tbody> 
        <?php 
            // connect with database
            include_once('include/database.php');
            // selecting posts from posts table
            $sql = "SELECT * FROM users";
            $result = mysqli_query($db, $sql);
            $resultCheck = mysqli_num_rows($result);

            if ($resultCheck < 1) {
                echo " ";
                    echo "<p> No users in Database </p>"; 
                echo " ";
            } else{
              
                while ($row = mysqli_fetch_array($result)) {
                
       
         echo "<tr>";
          echo "<td>" . $row["beneficiary_id"] . "</td>";  
           echo "<td>" . $row["fullname"] . "</td>";
             
             echo "<td>" . $row["status"] . "</td>";
              echo "<td>  <a href='profile.php?" .  $row["id"] ."' ><p>View</p></a> </td>";
         echo "</tr>";
       }
            }
       
        ?> 
       
    </tbody>  
  </table>  
   </div>
</div>
</div>
<script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
</body>
</html>
