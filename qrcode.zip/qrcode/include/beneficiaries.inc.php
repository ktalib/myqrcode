<?php
    session_start();
    include_once('connection.php');

    if(isset($_POST['add'])){ 
        $database = new Connection();
        $db = $database->open();
        try{
            //make use of prepared statement to prevent sql injection
            $stmt = $db->prepare("INSERT INTO users (fullname, username,  age, sex, beneficiary_id, household_size, pre_capita, community, email, status)    
            VALUES(:fullname,  :username, :age, :sex,  :beneficiary_id, :household_size, :pre_capita, :community, :email, :status )");



            //if-else statement in executing our prepared statement
            $_SESSION['message'] = ( $stmt->execute(array(
            ':fullname' => $_POST['fullname'],
            ':username' => $_POST['username'],
            ':age' => $_POST['age'], 
            ':sex' => $_POST['sex'],
            ':beneficiary_id' => $_POST['beneficiary_id'],
            ':household_size' => $_POST['household_size'],
            ':pre_capita' => $_POST['pre_capita'],
            ':community' => $_POST['community'],
            ':email' => $_POST['email'],
            ':status' => $_POST['status'])) ) ?
               'Member added successfully' 
               :'Something went wrong. Cannot add member';  
        
        }
        catch(PDOException $e){
            $_SESSION['message'] = $e->getMessage();
        }

        //close connection
        $database->close();
    }

    else{
        $_SESSION['message'] = 'Fill up add form first';
    }

    header('location: ../beneficiaries.php');
    
?>

 