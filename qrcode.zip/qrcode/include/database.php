<?php
    // errors show
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    //  connect with Database
    $db = mysqli_connect("localhost", "root", "", "ieeehsb");
?>