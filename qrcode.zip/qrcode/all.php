                  <?php
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','ieeehsb');
// Establish database connection.
try
{
$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}

  
$sql1 ="SELECT id from users where status=' Not Received'";
$query1 = $dbh -> prepare($sql1);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$nsum=$query1->rowCount();
 
 $sql1 ="SELECT id from users where status='RECEIVED'";
$query1 = $dbh -> prepare($sql1);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$rsum=$query1->rowCount();

$sql1 ="SELECT id from users";
$query1 = $dbh -> prepare($sql1);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$tsum=$query1->rowCount();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

<link rel='stylesheet' href='css/w3.css'>
 
  <link rel='stylesheet' href='assets/font-awesome/4.5.0/css/font-awesome.min.css' />
    <link rel="stylesheet" type="text/css" href="css/2.css">
 <script src="js/jquery.min.js"></script>
    <!-- text fonts -->
    <link rel='stylesheet' href='assets/css/fonts.googleapis.com.css' />
    <style type="text/css">.card {
    /* Add shadows to create the "card" effect */
    box-shadow: 0 4px 8px 0 rgb(0, 0, 0);
    transition: 0.3s;
}

/* On mouse-over, add a deeper shadow */
.card:hover {
    box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

/* Add some padding inside the card container */
.container {
    padding: 2px 16px;
}
.btn {
    border: none; /* Remove borders */
    color: white; /* Add a text color */
    padding: 14px 28px; /* Add some padding */
    cursor: pointer; /* Add a pointer cursor on mouse-over */
}

.success {background-color: #4CAF50;} /* Green */
.success:hover {background-color: #46a049;}

.info {background-color: #2196F3;} /* Blue */
.info:hover {background: #0b7dda;}

.warning {background-color: #ff9800;} /* Orange */
.warning:hover {background: #e68a00;}

.danger {background-color: #f44336;} /* Red */
.danger:hover {background: #da190b;}

.default {background-color: #e7e7e7; color: black;} /* Gray */
.default:hover {background: #ddd;}

</style>
</head>
<body style="background-color: #02292f;">

  <?php include 'nav.php'; ?>
 


<div id="header" align="center" style="padding-top: 100px;padding-bottom:100px;">
<h4 style="color: #fff;">Beneficairies Data</h4>
      
           
    
       <div class="card">
  <img src="img/all.png"   style="width:250px; height: 250px;">
  <div class="container">
    <h4 style="color: #fff;"><b>All Beneficiaries Are</b></h4>
     
    <button class="btn info"><?php echo htmlentities($tsum);?></button>
  </div>
</div>

<hr>
   <div class="card">
  <img src="img/not.png" style="width:250px; height: 250px;">
  <div class="container">
    <h4 style="color: #fff;"><b>Beneficiaries that are YET to RECIEVE Are</b></h4>
     
    <button class="btn warning"><?php echo htmlentities($nsum);?></button>
  </div>
</div>
<hr>

<div class="card">
  <img src="img/ok.png" style="width:250px; height: 250px;">
  <div class="container">
    <h4 style="color: #fff;"><b> RECEIVED Beneficiaries Are</b></h4>
    <button class="btn success"><?php echo htmlentities($rsum);?></button>
  </div>
</div>
</div>
</dvi>
</body>
</html>
