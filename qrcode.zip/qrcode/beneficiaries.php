  <?php
    function productcode() {
        $chars = "003232303232023232023456789";
        srand((double)microtime()*1000000);
        $i = 0;
        $pass = '' ;
        while ($i <= 7) {

            $num = rand() % 33;

            $tmp = substr($chars, $num, 1);

            $pass = $pass . $tmp;

            $i++;

        }
        return $pass;
    }
    $pcode='CAI-'.productcode();
    
 
?>

<!DOCTYPE html>
<html>
	<head>
		<a href=""></a>
		<meta charset="utf-8">
		<title>Registration</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
      
		<link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />
		<!-- LINEARICONS -->
		<link rel="stylesheet" href="fonts/linearicons/style.css">
		<link href="css/style1.css" rel="stylesheet" />
        <link href="css/2.css" rel="stylesheet" />
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
		<script src="assets/js/bootstrap.min.js"></script>
		    <link rel="stylesheet" type="text/css" href="css/2.css">
 <script src="js/jquery.min.js"></script>
	</head>

	<body style="background-color: #02292f;">

    
  
    <div id="navbar" style="background-color: #00365c;">
    <ul>
        <li id="home"><a href="home.php">HOME</a></li>
         
        <li id="games"><a href="beneficiaries.php">Register</a></li>
        <li id="contact"><a href="all.php">All Beneficiaries Data</a></li>
        <li   id="about" ><a href="search.php">Search</a></li>
        
    </ul>
    </div>
<!--||||||||||||||||||||||||||||||||||||||||||||||||||Div Mobile NavBar|||||||||||||||||||||||||||||||||||||||||||||||||||||-->
    <div id="m_navbar" style="background-color: #00365c;">
<a href="home.php" ><span class="fa fa-home"></span></a> <!--home-->
 
<a href="beneficiaries.php" ><span class="fa fa-pencil-square"></span></a> <!--news-->
<a href="search.php" ><span class="fa fa-search"></span></a> 

<a href="all.php" ><span class="fa fa-bar-chart-o"></span></a>
 

 
 
<!--about-->
    </div>
<div id="header" align="center" style="padding-top: 100px;padding-bottom:100px;">
		<div class="container">
			<div class="container">
				<img src="images/image-1.png" alt="" class="image-1">
            
				 <form id="contactform" method="POST" action="include/beneficiaries.inc.php"> 

                    <?php 
                session_start();
                if(isset($_SESSION['message'])){
                    ?>
                    <div class="alert alert-info text-center" style="margin-top:20px;">
                        <?php echo $_SESSION['message']; ?>
                    </div>
                    <?php

                    unset($_SESSION['message']);
                }
            ?>
					 
					<div class="form-holder">
					 
						
				
					<span  class="fa  fa-user">
						</span> 		  
					<input type="text" name="fullname" class="form-control" placeholder="First Name" required="" autocomplete="off">
				  
					</div>
   

					<div class="form-holder">
						<span class="fa fa-user"></span>
						 
						<input type="text" name="username" class="form-control" placeholder="Last Name" required=""    >
					</div>

					<div class="form-holder">
						<span class="lnr lnr-phone-handset"></span>
						 
						<input type="text" name="email" class="form-control" placeholder="Phone (+1232345)" required="" autocomplete="off">
					</div>

					<div class="form-holder">
						<span class="fa fa-calendar"></span>
					  
						<input type="text" name="age" class="form-control" placeholder="Age" required="" autocomplete="off">
					</div>
                     	<div class="form-holder">
						<span class="fa fa-camera-retro"></span>
						 
						<input type="file" name="image" class="form-control">
					</div>
					 
						<input type="hidden" name="beneficiary_id" class="form-control" 
						value="<?php echo "$pcode"; ?>">   
					 

					<div class="form-holder">
						<span class="fa fa-users"></span>
						 
						<input type="text" name="household_size" class="form-control" placeholder="Household Size" required="" autocomplete="off">
					</div>
             <div class="form-holder">
						<span class="fa fa-home"></span>
						<input type="text" name="community" class="form-control" placeholder="Community" required="" autocomplete="off" >
					</div>
					<div class="form-holder">
						<span class="fa fa-money"></span>
					 
						<input type="text" name="pre_capita" class="form-control" placeholder="Pre capital" required="" autocomplete="off"> 
					</div>
                   

						 
						<input type="hidden" name="status" class="form-control"    value=" Not Received"  autocomplete="off">
					 
					 

					  <!--  <div class="form-holder">
					   	<p>Photo</p>
						<span class="lnr lnr-phone-handset"></span>
						 
						<input type="file" name="status" class="form-control"    value=" Not Received"  >
					</div> -->
					 


					 
						<div class="form-holder">
					<span class="fa fa-venus-mars"></span>
					 
					<select class="form-control" name="sex">
                    <option value="">Gender</option>
					<option  value="Male">Male</option>
					<option  value="Female">Female</option>
					</select>
				</div>
				 
				 
					
					<button  name="add" id="submit"  type="submit">
						<span>Register</span>
					</button>
				</form>

				<img src="images/image-2.png" alt="" class="image-2">
			</div>
			
		</div>
		</div>
		<script src="js/jquery-3.3.1.min.js"></script>
		<script src="js/main.js"></script>
		  <script src="js/javascript.js" type="text/javascript"></script>
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>