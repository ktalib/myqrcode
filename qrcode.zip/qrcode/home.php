 
   
<!DOCTYPE html>
<html>
    <head>
    <title>Free Programming Books Sharing App</title>
        <link rel="stylesheet" type="text/css" href="css/style12.css">
      <link href="assets/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">
      <script src="js/main.js"></script>">

        <script src="js/javascript.js" type="text/javascript"></script>
        <meta charset="utf-8" >
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Cases Of COVID-19 In Nigeria android app">
        <meta name="keywords" content="android,symptoms,prevention">
        <meta name="author" content="iorkua Daniel">
    </head>
<body style="background-color: #02292f;">

    
 <?php include 'nav.php'; ?>
<!--||||||||||||||||||||||||||||||||||||||||||||||||||Div Mobile NavBar|||||||||||||||||||||||||||||||||||||||||||||||||||||-->
    

     
 <div id="header" align="center" style="padding-top: 100px;padding-bottom:100px;">

 
 

  <a href="#" class="btn" style="background: #80087d;" onmouseover="btn_title_show1('Scan for Qrcode')" onmouseout="btn_title_show('')" onclick="about_dialog_show1()"><span style="font-size: 50px;" class="fa fa-qrcode"></span><br> 

  </a>
  <a href="search.php" class="btn" style="background: #E91E63;" onmouseover="btn_title_show(' Search for Beneficiaries')" onmouseout="btn_title_show('')" ><span style="font-size: 50px;" class="fa fa-search"></span><br> </a>
 

  <a href="beneficiaries.php" class="btn" style="background: #300ca7;" onmouseover="btn_title_show('Register Beneficiaries') " onmouseout="btn_title_show('')"><span style="font-size: 50px;" class="fa fa-pencil-square"></span><br> </a>



 <a href="all.php" class="btn" style="background: #0c3803;" onmouseover="btn_title_show('Data')" onmouseout="btn_title_show('')"><span style="font-size: 50px;" class="fa fa-bar-chart-o"></span><br> 

  </a>
  

   <a href="include/logout.inc.php" class="btn" style="background: #021434;" onmouseover="btn_title_show('Logout')" onmouseout="btn_title_show('')"><span style="font-size: 50px;" class="fa fa-power-off"></span><br> 

  </a>




  <a href="#" class="btn" style="background: #190108;" onmouseover="btn_title_show('About app')" onmouseout="btn_title_show('')" onclick="about_dialog_show()"><span style="font-size: 50px;" class="fa fa-info-circle"></span><br> 

  </a>

 
 
<!--|||||||||||||||||||||||||||||||||||||||||||||||||||About Dialog||||||||||||||||||||||||||||||||||||||||||||||||||-->
 
</div>


 
</div>
     
 
<!--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||-->
</body>
</html>
 