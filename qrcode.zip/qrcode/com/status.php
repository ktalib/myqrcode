<?php
session_start();
error_reporting(0);
include('includes/config.php');
 

$stid=intval($_GET['stid']);

if(isset($_POST['submit']))
{ 
$status=$_POST['status'];
  
$classid=$_POST['class']; 
 
$sql="update users set status=:status where id=:stid ";
$query = $dbh->prepare($sql);
$query->bindParam(':status',$status,PDO::PARAM_STR);
 
$query->bindParam(':stid',$stid,PDO::PARAM_STR);
$query->execute();

$msg="!!";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/2.css">
  <script src="../j/jquery-3.3.1.min.js"></script>
  <script src="../js/poper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/main.js"></script>
  <link rel='stylesheet' href='../assets/font-awesome/4.5.0/css/font-awesome.min.css' />
  <style>
 

.icon-bar {
  width: 100%;
  background-color: #555;
  overflow: auto;
}

.icon-bar a {
  float: left;
  width: 20%;
  text-align: center;
  padding: 12px 0;
  transition: all 0.3s ease;
  color: white;
  font-size: 36px;
}

.icon-bar a:hover {
  background-color: #000;
}

.active {
  background-color: #4CAF50;
}
</style>
</head>
<body style="background-color: #02203a;"> 
 
   <?php include 'nav.php'; ?>

<div class="container">
  <h2 style="color: #fff">Beneficiary Status</h2>
  <div class="card"   style="background-color: #032a21;">
    <div class="card-body">  <div class="row">
    <div class="col-md-12">
      <div class="panel">
        <div class="panel-heading">


          <?php 

$sql = "SELECT users.status, users.fullname, users.username from users where users.id=:stid";
$query = $dbh->prepare($sql);
$query->bindParam(':stid',$stid,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{  ?>

          <div class="panel-title">
          <h5 style="color: #fff"><?php echo htmlentities($result->fullname)?> <?php echo htmlentities($result->fullname)?> Has <?php echo htmlentities($result->status)?> </h5>
                </div>
            </div>
            <div class="panel-body">
<?php if($msg){?>
<div class="alert alert-success left-icon-alert" role="alert">
 <strong>Beneficiary Received successfully </strong><?php echo htmlentities($msg); ?>
 </div><?php } 
else if($error){?>
    <div class="alert alert-danger left-icon-alert" role="alert">
      <strong>Oh snap!</strong> <?php echo htmlentities($error); ?>
                                        </div>
                                        <?php } ?>
                                                <form class="form-horizontal" method="post">


<div class="form-group">
<label for="default" class="col-sm-2 control-label" style="color: #fff">Select Beneficiary Status and Click ok</label>
<div class="col-sm-10">
 
            <span></span>
          <select class="form-control" name="status">
                     
          <option  value="<?php echo htmlentities($result->status)?>" ><?php echo htmlentities($result->status)?></option>
          <option  value="RECEIVED">RECEIVED</option>
          
          </select>
        </div>
</div>
</div>
</div>
</div>
<?php }} ?>                                                    

                                                    
                      <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" name="submit" class="btn btn-primary">
                      GO</button>
                              </div>
                          </div>

                      <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                   
                       
                             <a href="../home.php" class="btn btn-primary">
                               Home
                               </a>
              
                     
                              </div>
                          </div>
                      </form>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>
                   </div>
</div>
</body>
</html>
