<?php
    include_once("include/head.php");
?>
    <div class="container mt-4">
        <div class="jumbotron">
            <h1 class="display-4">Hello</h1>
            <p class="lead">Welcome to Christian Aid International</p>
               <a href="register.php">Login</a> </p>
        </div>
    </div>
    
<?php
    include_once("include/footer.html");
?>
