function dropdownmenu() {
    document.getElementById("dropdownmenu").style.display = 'block';
}
function dropdownmenu_hide() {
    document.getElementById("dropdownmenu").style.display = 'none';
}
function about_dialog_show() {
    document.getElementById("about_dialog_bg").style.display = 'block';
}


function about_dialog_show1() {
    document.getElementById("about_dialog_bg1").style.display = 'block';
}


function about_dialog_show2() {
    document.getElementById("about_dialog_bg2").style.display = 'block';
}

function about_dialog_hide() {
    document.getElementById("about_dialog_bg").style.display = 'none';
}

function about_dialog_hide1() {
    document.getElementById("about_dialog_bg1").style.display = 'none';
}
 

function about_dialog_hide2() {
    document.getElementById("about_dialog_bg2").style.display = 'none';
}

function btn_title_show(title) {
    document.getElementById('btn_title').innerHTML = title;
}
function btn_title_hide() {
    document.getElementById('btn_title').innerHTML = '';
}
 